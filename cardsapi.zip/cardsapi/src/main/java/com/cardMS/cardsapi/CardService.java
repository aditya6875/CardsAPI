package com.cardMS.cardsapi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CardService {

    @Autowired
    private CardRepository cardRepo;

    public List<Card> getCards(){
        return cardRepo.findAll();

    }

    public Card addCards(Card card){
        return cardRepo.save(card);
//        console.log(card);
    }

    public void updateCards(Card card){
        cardRepo.save(card);

    }

    public void deleteCards(Integer id){
        cardRepo.deleteById(id);
    }
}
