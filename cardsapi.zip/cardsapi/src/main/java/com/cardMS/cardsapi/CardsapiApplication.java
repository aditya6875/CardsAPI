package com.cardMS.cardsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardsapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardsapiApplication.class, args);
	}

}
