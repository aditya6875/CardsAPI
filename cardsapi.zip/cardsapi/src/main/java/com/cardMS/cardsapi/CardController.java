package com.cardMS.cardsapi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.Console;
import java.util.List;

@RestController
@CrossOrigin
public class CardController {

    @Autowired
    private CardService cardServ;

    @GetMapping("/card")
    public List<Card> getCards(){
        return cardServ.getCards();
    }

    @PostMapping("/card/add")
    public Card addCards(@RequestBody Card card){
        return cardServ.addCards(card);

    }

    @PutMapping("/card/{id}/edit")
    public void updateCards(@PathVariable("id") Integer id,@RequestBody Card card){
        cardServ.updateCards(card);

    }

    @DeleteMapping("/card/{id}/delete")
    public void deleteCards(@PathVariable("id") Integer id){
        cardServ.deleteCards(id);

    }

}
