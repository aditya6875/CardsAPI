package com.cardMS.cardsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardsapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
